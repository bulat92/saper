export const increaseCellStateInFieldMapFunc = (fieldMap) => {
  
  return fieldMap;
};
