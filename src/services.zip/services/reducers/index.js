import { combineReducers } from "@reduxjs/toolkit";
import madedField from './madeField';

export const rootReducer = combineReducers({
    madedField
})
