import { createSlice } from "@reduxjs/toolkit";
import { openField } from "../../consts";
import { increaseCellStateInFieldMapFunc } from './increaseCellStateInFieldMapFunc'

export const initialState = {
  fieldMap: openField(),
  NumOfMines: 40,
  play: false,
};
 
const madedField = createSlice({
  name: "madedField",
  initialState,
  reducers: {
    increaseCellStateInFieldMap: (state) => {
      state.fieldMap = increaseCellStateInFieldMapFunc(state.fieldMap);
    },
    putTheBombInCell: (state, action) => {
      state.fieldMap = state.fieldMap.map((cellRow) =>
        cellRow.map((cell) =>
          cell.id !== action.payload ? cell : { id: cell.id, cellState: -1 }
        )
      );
    },
    increaseNumOfMines: (state) => {
      state.NumOfMines = state.NumOfMines + 1;
    },
    decreaseNumOfMines: (state) => {
      state.NumOfMines = state.NumOfMines !== 0 ? state.NumOfMines - 1 : 0;
    },
    startPlay: (state) => {
      state.play = true;
    },
    newGame: (state) => {
      state.play = false;
      state.fieldMap = openField();
      state.NumOfMines = 40;
    },
  },
});

export const {
  putTheBombInCell,
  increaseCellStateInFieldMap,
  increaseNumOfMines,
  decreaseNumOfMines,
  startPlay,
  newGame,
} = madedField.actions;
export default madedField.reducer;
