import style from "./header.module.css";
import { Stopwatch } from "./stopwatch/stopwatch";
import { NumberOfMines } from "./number-of-mines/number-of-mines";
import { useState } from "react";
import { newGame } from "../../services/reducers/madeField";
import { useDispatch } from "react-redux";

export const Header = ({ img }) => {
  const dispatch = useDispatch();
  const [imgDefault, setImgDefault] = useState("-1px -25px");

  const newGameFunc = () => {
    dispatch(newGame());
  };
  return (
    <div className={style.header}>
      <NumberOfMines />
      <div
        onMouseDown={() => setImgDefault("-27px -24px")}
        onMouseUp={() => setImgDefault("-1px -25px")}
        className={style.smiley}
        onClick={newGameFunc}
        style={{ backgroundPosition: img ? img : imgDefault }}
      ></div>
      <Stopwatch />
    </div>
  );
};
